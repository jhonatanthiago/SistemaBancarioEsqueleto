package repository;

import java.util.ArrayList;
import java.util.List;
import model.Conta;

public class ContaRepository {

    private List<Conta> contas = new ArrayList<>();

    public void salvar(Conta conta){
        contas.add(conta);
    }

    public Conta buscarPorNumero(String numero){
        for(Conta c : contas){
            if(c.getNumero().equals(numero)){
                return c;
            }
        }
        return null;
    }
}
