package model;

public class Conta {

    private String numero;
    private String dono;
    private double saldo;

    public Conta(String numero, String dono) {
        this.numero = numero;
        this.dono = dono;
        this.saldo = 0.0;
    }

    public String getNumero() {
        return numero;
    }

    public String getDono() {
        return dono;
    }

    public double getSaldo() {
        return saldo;
    }

    public void depositar(double valor) {
        this.saldo += valor;
    }

    public boolean sacar(double valor) {
        if(valor <= saldo){
            saldo -= valor;
            return true;
        }
        return false;
    }
}
