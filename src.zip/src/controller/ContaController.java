package controller;

import service.ContaService;

public class ContaController {

    private ContaService service = new ContaService();

    public void criarConta(String numero, String dono){
        System.out.println(service.criarConta(numero, dono));
    }

    public void consultar(String numero){
        System.out.println(service.consultarSaldo(numero));
    }

    public void depositar(String numero, double valor){
        System.out.println(service.depositar(numero, valor));
    }

    public void sacar(String numero, double valor){
        System.out.println(service.sacar(numero, valor));
    }
}
