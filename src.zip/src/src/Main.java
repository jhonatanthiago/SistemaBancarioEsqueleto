import controller.ContaController;

public class Main {

    public static void main(String[] args) {

        ContaController controller = new ContaController();

        controller.criarConta("123", "Thiago");
        controller.depositar("123", 100);
        controller.consultar("123");
        controller.sacar("123", 50);
        controller.consultar("123");
    }
}
