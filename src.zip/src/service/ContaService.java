package service;

import model.Conta;
import repository.ContaRepository;

public class ContaService {

    private ContaRepository repository = new ContaRepository();

    public Conta criarConta(String numero, String dono){
        Conta conta = new Conta(numero, dono);
        repository.salvar(conta);
        return conta;
    }

    public String consultarSaldo(String numero){
        Conta conta = repository.buscarPorNumero(numero);
        if(conta != null){
            return "Saldo atual: " + conta.getSaldo();
        }
        return "Conta não encontrada!";
    }

    public String depositar(String numero, double valor){
        Conta conta = repository.buscarPorNumero(numero);
        if(conta != null){
            conta.depositar(valor);
            return "Depósito realizado com sucesso!";
        }
        return "Conta não encontrada!";
    }

    public String sacar(String numero, double valor){
        Conta conta = repository.buscarPorNumero(numero);
        if(conta != null){
            if(conta.sacar(valor)){
                return "Saque realizado!";
            } else {
                return "Saldo insuficiente!";
            }
        }
        return "Conta não encontrada!";
    }
}
